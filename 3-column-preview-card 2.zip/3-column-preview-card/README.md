# 3-Column Preview Card Component

A beginner-friendly HTML and CSS solution to the Frontend Mentor 3-column preview card challenge.

## Files
- `index.html` — the page content
- `styles.css` — the design and responsive layout
- `assets/images/` — the three car icons

## Run locally
Open `index.html` in your browser, or use Live Server in VS Code.

## GitHub and Vercel
1. Create a GitHub repository named `3-column-preview-card`.
2. Upload the contents of this folder (not just the ZIP file). Keep `index.html` and `styles.css` at the top level and include the `assets` folder.
3. Sign in to Vercel using GitHub, choose **Add New → Project**, import `3-column-preview-card`, and deploy.
4. Copy the `.vercel.app` link shown after deployment.

The project files have been prepared, but they have not been uploaded to your personal GitHub account or deployed to Vercel.
